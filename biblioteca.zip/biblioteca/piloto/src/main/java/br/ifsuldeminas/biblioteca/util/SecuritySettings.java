package br.ifsuldeminas.biblioteca.util;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecuritySettings extends WebSecurityConfigurerAdapter {
	
	@Autowired
	private DataSource dataSource;
	
	 @Bean
	 public static BCryptPasswordEncoder passwordEncoder() {
		 return new BCryptPasswordEncoder();
	 }
	 
	 //autenticação em banco de dados
	 //withUser nome do usuario
	 //encode senha
	 @Override
	 protected void configure(AuthenticationManagerBuilder auth) throws Exception{
		 auth.jdbcAuthentication().dataSource(dataSource).usersByUsernameQuery("select usuarios.nome as username, usuarios.senha as password, 1 as enable from usuarios where nome = ?").authoritiesByUsernameQuery("select usuarios.nome as username, papeis.role as authority from permissao inner join usuarios on usuarios.id=permissao.usuario_id inner join papeis on papeis.id=permissao.papel_id where usuarios.nome=?").passwordEncoder(new BCryptPasswordEncoder());
	 }
	 
	 @Override
	 protected void configure(HttpSecurity http) throws Exception{
		http.csrf().disable().authorizeRequests()
		//.antMatchers("/listarRole","/cadastrarRole","/salvarRole","/editarRole","/excluirRole").hasAuthority("papel")
		//.antMatchers("/listarPermissao", "/cadastrarPermissao", "/salvarPermissao", "/editarPermissao", "/excluirPermissao").hasAuthority("permissao")
		//.antMatchers("/listarUsuario", "/cadastrarUsuario", "/salvarUsuario", "/editarUsuario", "/excluirUsuario").hasAuthority("usuario")
		//.antMatchers("/listarCidade", "/cadastrarCidade", "/salvarCidade", "/editarCidade", "/excluirCidade").hasAuthority("cidade")
		//.antMatchers("/listarEstado", "/cadastrarEstado", "/salvarEstado", "/editarEstado", "/excluirEstado").hasAuthority("estado")
		.and().formLogin().loginPage("/login").permitAll().and().logout()
		.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
		.logoutSuccessUrl("/")
		.and()
		.exceptionHandling()
		.accessDeniedPage("/negarAcesso");
	 } 
	 
}
