package br.ifsuldeminas.biblioteca.domains;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name="livros")
public class Livro {

		public Livro() {
			
		}
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long id;
		
		@Column
		@NotBlank(message ="Qual o nome do Livro?")
		private String nome;
		
		@Column
		@Length(min = 2, max = 20, message = "Qual a sigla da Editora")
		private String siglaEditora;
		
		@ManyToOne
		private Autor autor;
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getNome() {
			return nome;
		}
		public void setNome(String nome) {
			this.nome = nome;
		}
		public Autor getAutor() {
			return autor;
		}
		public void setAutor(Autor autor) {
			this.autor = autor;
		}
		
		public String getSigla() {
			return siglaEditora;
		}

		public void setSigla(String siglaEditora) {
			this.siglaEditora = siglaEditora;
		}
		
		@Override
		public String toString() {
			return nome + "do Autor:" + autor;
		}
		
		@Override
		public int hashCode() {
			return Objects.hash(id, nome, siglaEditora);
		}
		
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Livro other = (Livro) obj;
			return Objects.equals(id, other.id)&& Objects.equals(nome, other.nome) && Objects.equals(siglaEditora, other.siglaEditora);
		}
		
		
		
}
