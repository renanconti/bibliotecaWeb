package br.ifsuldeminas.biblioteca.domains;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name="papeis")
public class Papel {
	 	
	
		public Papel() {
			
		}
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long id;
		
		@Column
		@NotBlank(message ="Preencha o campo Cargo")
		private String role;
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		
		
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		@Override
		public int hashCode() {
			return Objects.hash(id, role);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Papel other = (Papel) obj;
			return Objects.equals(id, other.id);
		}
		@Override
		public String toString() {
			return  role ;
		}
	
		
		
}
