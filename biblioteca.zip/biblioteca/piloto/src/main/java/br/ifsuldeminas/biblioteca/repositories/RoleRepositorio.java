package br.ifsuldeminas.biblioteca.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.ifsuldeminas.biblioteca.domains.Papel;

public interface RoleRepositorio extends JpaRepository<Papel, Long> {

}
