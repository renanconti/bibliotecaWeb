package br.ifsuldeminas.biblioteca.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.ifsuldeminas.biblioteca.domains.Livro;


public interface LivroRepositorio extends JpaRepository<Livro, Long> {

}
