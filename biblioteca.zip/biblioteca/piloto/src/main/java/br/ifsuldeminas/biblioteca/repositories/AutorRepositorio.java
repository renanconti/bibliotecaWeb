package br.ifsuldeminas.biblioteca.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.ifsuldeminas.biblioteca.domains.Autor;



public interface AutorRepositorio extends JpaRepository<Autor, Long> {

}