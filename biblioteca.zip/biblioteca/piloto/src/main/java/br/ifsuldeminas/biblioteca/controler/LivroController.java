package br.ifsuldeminas.biblioteca.controler;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import br.ifsuldeminas.biblioteca.domains.Livro;
import br.ifsuldeminas.biblioteca.repositories.AutorRepositorio;
import br.ifsuldeminas.biblioteca.repositories.LivroRepositorio;

@Controller
public class LivroController {
	
	@Autowired
	private LivroRepositorio livroRepo;
	@Autowired
	private AutorRepositorio autorRepo;
	
	@GetMapping("/listarLivro")
	public ModelAndView listar(){
		ModelAndView mv = new ModelAndView("livros");
		mv.addObject("livros",livroRepo.findAll());
		
		return mv;
	}
	
	@GetMapping("/cadastrarLivro")
	public ModelAndView cadastrar (Livro livro) {
		ModelAndView mv = new ModelAndView("livro");
		mv.addObject("livro", livro);
		mv.addObject("autores",autorRepo.findAll());
		
		return mv;
	}
	

	@PostMapping("/salvarLivro") 
	public ModelAndView salvar(@Valid Livro livro, BindingResult result) {
		if(result.hasErrors()) {
			return cadastrar(livro);
		}
			livroRepo.saveAndFlush(livro);
	
			return new ModelAndView("redirect:/listarLivro");
	}

	@GetMapping ("/editarLivro/{id}")
	public ModelAndView editar(@PathVariable("id")Long id) {
		Optional<Livro> livro = livroRepo.findById(id);
		
		return cadastrar (livro.get());
	}
	
	@GetMapping ("/excluirLivro/{id}")
	public ModelAndView excluir(@PathVariable("id")Long id) {
		Optional<Livro> livro = livroRepo.findById(id);
		livroRepo.delete(livro.get());
		
		return new ModelAndView("redirect:/listarLivro");
}
	
}
