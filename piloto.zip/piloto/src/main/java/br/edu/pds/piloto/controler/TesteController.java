//controller teste
package br.edu.pds.piloto.controler;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TesteController {
	
String mensagem = "Olá Mundo Spring(Dinamico)";

@GetMapping("/olaMundo")
public ModelAndView olaMundoDinamico() {
	
	ModelAndView mv = new ModelAndView("index.html");
	mv.addObject("mensagem", mensagem);
	
	return mv;
	}
}
