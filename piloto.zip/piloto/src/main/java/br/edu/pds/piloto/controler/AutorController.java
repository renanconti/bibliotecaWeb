package br.edu.pds.piloto.controler;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import br.edu.pds.piloto.domains.Autor;
import br.edu.pds.piloto.repositories.AutorRepositorio;

@Controller
public class AutorController {

    @Autowired
    private AutorRepositorio autorRepo;

    @GetMapping("/cadastrarAutor")
    public ModelAndView cadastrar(Autor autor){
        ModelAndView mv = new ModelAndView("autor");
        mv.addObject("autor", autor);
        return mv;
    }

    @GetMapping("/listarAutor")
    public ModelAndView listar(){
        ModelAndView mv = new ModelAndView("autores");
        mv.addObject("autores", autorRepo.findAll());
        return mv;
    }


    @PostMapping("/salvarAutor")
    public ModelAndView salvar(@Valid Autor autor, BindingResult result){
        if(result.hasErrors()){
            return cadastrar(autor);
        }

        autorRepo.saveAndFlush(autor);

        return new ModelAndView("redirect:/listarAutor");
    }

    @GetMapping("/editarAutor/{id}")
    public ModelAndView editar(@PathVariable("id") Long id){
        Optional<Autor> autor = autorRepo.findById(id);
        return cadastrar(autor.get());
    }

    @GetMapping("/excluirAutor/{id}")
    public ModelAndView excluir(@PathVariable("id") Long id){
        Optional<Autor> autor = autorRepo.findById(id);
        autorRepo.delete(autor.get());
        return new ModelAndView("redirect:/listarAutor");
    }
}